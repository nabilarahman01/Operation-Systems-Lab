/*
Author: Kazi Toufique Elahi
ID: 190104116
Code: SSTF (Shortest Seek Time First) Scheduling
*/

#include <bits/stdc++.h>
using namespace std;

int req[10000];
bool is_read[10000];

int main()
{
    int n_head;
    cout << "Number of heads: ";
    cin >> n_head;

    int n_req;
    cout << "Number of requests: ";
    cin >> n_req;

    cout << "Cylinder requests: ";
    for (int i = 0; i < n_req; ++i) {
        cin >> req[i];
    }

    int curr_head;
    cout << "Current head positions: ";
    cin >> curr_head;

    vector<int> sequence;
    int movement = 0;

    sequence.push_back(curr_head);
    for (int i = 0; i < n_req; ++i) {
        int shortest_dist = INT_MAX;
        int shortest_dist_idx = 0;

        for (int j = 0; j < n_req; ++j) {
            if (!is_read[j] && abs(req[j] - curr_head) < shortest_dist) {
                shortest_dist = abs(req[j] - curr_head);
                shortest_dist_idx = j;
            }
        }

        movement += shortest_dist;
        is_read[shortest_dist_idx] = true;
        curr_head = req[shortest_dist_idx];
        sequence.push_back(curr_head);
    }

    cout << "Cylinder Serving Order: ";

    int len = sequence.size();
    for (int i = 0; i < len; ++i) {
        cout << sequence[i];
        if (i != len - 1) {
            cout << " -> ";
        }
    }
    cout << endl;

    cout << "Total Cylinder movement: " << movement << endl;

    return 0;

}


/*

--------Sample Input--------
200
8
98 183 37 122 14 124 65 67
53

*/
