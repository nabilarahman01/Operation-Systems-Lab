/*
Author: Kazi Toufique Elahi
ID: 190104116
Code: Page Replacement Algorithms (FIFO, Optimal, LRU)
*/

#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <list>
using namespace std;

int arr_ref[1000];

void fifo (int n_ref, int n_frame) {
    list<int> lst;
    list<int>::iterator it;
    int  miss = 0;
    for (int i = 0; i < n_ref; ++i) {
        it = find(lst.begin(), lst.end(), arr_ref[i]);
        if (it == lst.end()) {
            if(lst.size() == n_frame) {
                lst.pop_front();
            }
            lst.push_back(arr_ref[i]);
            ++miss;
        }
    }
    cout << "Number of page fault using FIFO Page replacement Algorithm: " << miss << endl;
    cout << "Page Fault Rate: " << (int) round(miss * 100.00 / n_ref) << "%" << endl;
}

void optimal (int n_ref, int n_frame) {
    vector<int> dist(n_ref, INT_MAX);
    int  miss = 0;
    
    for (int i = n_ref - 1; i >= 0; --i) {
        if (dist[i] != INT_MAX) {
            continue;
        }
        int last_idx = i;
        for (int j = last_idx - 1; j >= 0; --j) {
            if (arr_ref[i] == arr_ref[j]) {
                dist[j] = last_idx;
                last_idx = j;
            }
        }
    }

    vector<pair<int, int> > v;
    vector<pair<int, int> >::iterator it;

    for (int i = 0; i < n_ref; ++i) {
        int curr = arr_ref[i];
        it = find_if(v.begin(), v.end(), [&curr](const pair<int, int> &a) {return a.first == curr;});
        if (it == v.end()) {
            if (v.size() == n_frame) {
                int mx_idx = 0;
                int mx_dist = INT_MIN;
                for (int j = 0; j < v.size(); ++j) {
                    if (v[j].second > mx_dist) {
                        mx_dist = v[j].second;
                        mx_idx = j;
                    }
                }
                v[mx_idx] = make_pair(arr_ref[i], dist[i]);
            }
            else {
                v.push_back(make_pair(arr_ref[i], dist[i]));
            }
            ++miss;
        }
        else {
            *it = make_pair(arr_ref[i], dist[i]);
        }
    }
    cout << "Number of page fault using Optimal Page replacement Algorithm: " << miss << endl;
    cout << "Page Fault Rate: " << (int) round(miss * 100.00 / n_ref) << "%" << endl;
}

void lru (int n_ref, int n_frame) {
    list<int> lst;
    list<int>::iterator it;
    int miss = 0;
    for (int i = 0; i < n_ref; ++i) {
        it = find(lst.begin(), lst.end(), arr_ref[i]);
        if (it == lst.end()) {
            if (lst.size() == n_frame) {
                lst.pop_front();
            }
            lst.push_back(arr_ref[i]);
            ++miss;
        }
        else {
            int temp = *it;
            lst.erase(it);
            lst.push_back(temp);
        }
    }
    cout << "Number of page fault using Least Recently Used Page replacement Algorithm: " << miss << endl;
    cout << "Page Fault Rate: " << (int) round(miss * 100.00 / n_ref) << "%" << endl;
}

int main () {
    int n_page, n_ref, n_frame;
    
    cout << "Number of pages: ";
    cin >> n_page;

    cout << "Number of Page References: ";
    cin >> n_ref;

    cout << "Reference String: ";
    for (int i = 0; i < n_ref; ++i) {
        cin >> arr_ref[i];
        cin.ignore();
    }

    cout << "Number of Memory Page Frame: ";
    cin >> n_frame;

    fifo(n_ref, n_frame);
    optimal(n_ref, n_frame);
    lru(n_ref, n_frame);

    return 0;

}

/*
----------Sample Input----------
8
22
7,0,1,2,0,3,0,4,2,3,0,3,0,3,2,1,2,0,1,7,0,1
3
*/