#include<iostream>
#include<algorithm>

struct Process
{
    int arrivalTime;
    int cpuTime;
    int waitingTime;
    int turnAroundTime;
    int listedName;
    int startingTime;
};

bool comparator(Process A, Process B)
{
    return A.arrivalTime < B.arrivalTime;
}

bool comparatorName(Process A, Process B)
{
    return A.listedName < B.listedName;
}


int main()
{
    int len;
    std::cout << "Enter the number of process: ";
    std::cin >> len;
    Process processList[len];

    std::cout << "Enter the CPU times: " << std::endl;
    for(int i = 0; i < len; ++i)
    {
        processList[i].listedName = i + 1;
        std::cin >> processList[i].cpuTime;
    }

    std::cout << "Enter the Arrival times: " << std::endl;
    for(int i = 0; i < len; ++i)
    {
        std::cin >> processList[i].arrivalTime;
    }
    std::sort(processList, processList + len, comparator);
    processList[0].startingTime = 0;
    processList[0].waitingTime = 0;
    processList[0].turnAroundTime = processList[0].cpuTime;
    for(int i = 1; i < len; ++i)
    {
        int temp = processList[i - 1].startingTime + processList[i - 1].cpuTime;
        if(processList[i].arrivalTime > temp)
        {
            processList[i].startingTime = processList[i].arrivalTime;
            processList[i].waitingTime = 0;
        }
        else
        {
            processList[i].startingTime = temp;
            processList[i].waitingTime = temp - processList[i].arrivalTime;
        }
        processList[i].turnAroundTime = processList[i].waitingTime + processList[i].cpuTime;
    }
    std::sort(processList, processList + len, comparatorName);
    int sumWaitingTime = 0;
    int sumTurnaroundTime = 0;
    for(int i = 0; i < 3; ++i)
    {
        std::cout << "Process " << processList[i].listedName << ": Waiting Time: " << processList[i].waitingTime << "\tTurnaround Time: " << processList[i].turnAroundTime << std::endl;
        sumWaitingTime += processList[i].waitingTime;
        sumTurnaroundTime += processList[i].turnAroundTime;
    }
    std::cout << "Average Waiting time:" << sumWaitingTime * 1.0f / len << std::endl;
    std::cout << "Average Turnaroud time:" << sumTurnaroundTime * 1.0f / len << std::endl;
    return 0;
}
