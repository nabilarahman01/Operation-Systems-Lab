/*
Author: Kazi Toufique Elahi
ID: 190104116
Code: Memory Allocation Techniques (First fit, Best fit, Worst fit)
*/

#include<iostream>
using namespace std;

void horizontal_ln(int len) {
    for (int i = 0; i < len * 8; ++i) {
        cout << "_";
    }
    cout << endl;
}

void first_fit(int *holes, int *requests, int hole_n, int req_n) {
    cout << "\nFirst Fit" << endl;
    int unfilled_req = -1;
    int step_table[hole_n][req_n];
    int temp_holes[hole_n];

    for (int i = 0; i < hole_n; ++i) {
        temp_holes[i] = holes[i];
    }

    for (int i = 0; i < req_n; ++i) {
        bool stop = true;
        for (int j = 0; j < hole_n; ++j) {
            if (requests[i] < temp_holes[j]) {
                temp_holes[j] -= requests[i];
                for (int k = 0; k < hole_n; ++k) {
                    step_table[k][i] = temp_holes[k];
                }
                stop = false;
                break;
            }
        }

        if (stop) {
            unfilled_req = i;
            break;
        }
    }
    cout << "Memory Allocation Step by step:" << endl;
    for (int i = 0; i < req_n; ++i) {
        cout << requests[i] << "\t";
    }
    cout << endl;
    for (int i = 0; i < hole_n; ++i) {
        for (int j = 0; j < req_n; ++j) {
            if (j == unfilled_req) {
                if (i == 0) {
                    cout << "CAN\'T\t";
                }
                else if (i == 1) {
                    cout << "BE\t";
                }
                else if (i == 2) {
                    cout << "ALLOCATED\t";
                }
                else {
                    break;
                }
            }
            else {
                cout << step_table[i][j] << "\t";
            }
        }
        cout << endl;
    }

    int frag = 0;
    if (unfilled_req == -1) {
        cout << "No External Fragmentation" << endl;
    }
    else if (unfilled_req == 0) {
        for (int i = 0; i < hole_n; ++i) {
            frag += requests[i];
        }
        cout << "External Fragmentation: " << frag << endl;
    }
    else {
        --unfilled_req;
        for (int i = 0; i < hole_n; ++i) {
            frag += step_table[i][unfilled_req];
        }
        cout << "External Fragmentation: " << frag << endl;
    }
}

void worst_fit(int *holes, int *requests, int hole_n, int req_n) {
    cout << "\nWorst Fit" << endl;
    int unfilled_req = -1;
    int step_table[hole_n][req_n];
    int temp_holes[hole_n];

    for (int i = 0; i < hole_n; ++i) {
        temp_holes[i] = holes[i];
    }

    for (int i = 0; i < req_n; ++i) {
        int selected_index = -1;
        int max_hole = -1;
        for (int j = 0; j < hole_n; ++j) {
            if (max_hole < temp_holes[j]) {
                max_hole = temp_holes[j];
                selected_index = j;
            }
        }
        if (max_hole < requests[i]) {
            unfilled_req = i;
            break;
        }
        else {
            temp_holes[selected_index] -= requests[i];
            for (int k = 0; k < hole_n; ++k) {
                step_table[k][i] = temp_holes[k];
            }
        }
    }
    cout << "Memory Allocation Step by step:" << endl;
    for (int i = 0; i < req_n; ++i) {
        cout << requests[i] << "\t";
    }
    cout << endl;
    for (int i = 0; i < hole_n; ++i) {
        for (int j = 0; j < req_n; ++j) {
            if (j == unfilled_req) {
                if (i == 0) {
                    cout << "CAN\'T\t";
                }
                else if (i == 1) {
                    cout << "BE\t";
                }
                else if (i == 2) {
                    cout << "ALLOCATED\t";
                }
                else {
                    break;
                }
            }
            else if (j > unfilled_req) {
                break;
            }
            else {
                cout << step_table[i][j] << "\t";
            }
        }
        cout << endl;
    }

    int frag = 0;
    if (unfilled_req == -1) {
        cout << "No External Fragmentation" << endl;
    }
    else if (unfilled_req == 0) {
        for (int i = 0; i < hole_n; ++i) {
            frag += requests[i];
        }
        cout << "External Fragmentation: " << frag << endl;
    }
    else {
        --unfilled_req;
        for (int i = 0; i < hole_n; ++i) {
            frag += step_table[i][unfilled_req];
        }
        cout << "External Fragmentation: " << frag << endl;
    }
}

void best_fit(int *holes, int *requests, int hole_n, int req_n) {
    cout << "\nBest Fit" << endl;
    int unfilled_req = -1;
    int step_table[hole_n][req_n];
    int temp_holes[hole_n];

    for (int i = 0; i < hole_n; ++i) {
        temp_holes[i] = holes[i];
    }

    for (int i = 0; i < req_n; ++i) {
        int selected_index = -1;
        int min_hole = INT_MAX;
        for (int j = 0; j < hole_n; ++j) {
            if (min_hole > temp_holes[j] && requests[i] <= temp_holes[j]) {
                min_hole = temp_holes[j];
                selected_index = j;
            }
        }
        if (selected_index == -1) {
            unfilled_req = i;
            break;
        }
        else {
            temp_holes[selected_index] -= requests[i];
            for (int k = 0; k < hole_n; ++k) {
                step_table[k][i] = temp_holes[k];
            }
        }
    }
    cout << "Memory Allocation Step by step:" << endl;
    for (int i = 0; i < req_n; ++i) {
        cout << requests[i] << "\t";
    }
    cout << endl;
    for (int i = 0; i < hole_n; ++i) {
        for (int j = 0; j < req_n; ++j) {
            if (j == unfilled_req) {
                if (i == 0) {
                    cout << "CAN\'T\t";
                }
                else if (i == 1) {
                    cout << "BE\t";
                }
                else if (i == 2) {
                    cout << "ALLOCATED\t";
                }
                else {
                    break;
                }
            }
            else if (j > unfilled_req && unfilled_req != -1) {
                break;
            }
            else {
                cout << step_table[i][j] << "\t";
            }
        }
        cout << endl;
    }

    int frag = 0;
    if (unfilled_req == -1) {
        cout << "No External Fragmentation" << endl;
    }
    else if (unfilled_req == 0) {
        for (int i = 0; i < hole_n; ++i) {
            frag += requests[i];
        }
        cout << "External Fragmentation: " << frag << endl;
    }
    else {
        --unfilled_req;
        for (int i = 0; i < hole_n; ++i) {
            frag += step_table[i][unfilled_req];
        }
        cout << "External Fragmentation: " << frag << endl;
    }
}


int main() {
    int hole_n, req_n;
    cout << "Number of Memory holes: ";
    cin >> hole_n;

    int holes[hole_n];
    cout << "Memory holes: ";
    for (int i = 0; i < hole_n; ++i) {
        cin >> holes[i];
    }

    cout << "Number of Memory Requests: ";
    cin >> req_n;

    int requests[req_n];
    cout << "Memory Requests: ";
    for (int i = 0; i < req_n; ++i) {
        cin >> requests[i];
    }

    first_fit(holes, requests, hole_n, req_n);
    worst_fit(holes, requests, hole_n, req_n);
    best_fit(holes, requests, hole_n, req_n);

    return 0;
}

/*
----------Sample Input----------
5
50 200 70 115 15
10
100 10 35 15 23 6 25 55 88 40
*/
