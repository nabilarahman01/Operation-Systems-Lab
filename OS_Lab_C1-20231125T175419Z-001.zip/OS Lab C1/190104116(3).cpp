/*
Author: Kazi Toufique Elahi
ID: 190104116
Code: Least Recently Used page replacement algorithm using stack, Enhanced second chance algorithm
*/

#include <bits/stdc++.h>
using namespace std;

int arr_ref[10000];

void lru_using_stack(int n_ref, int n_frame)
{
    stack<int> primary, secondary;
    vector<stack<int> > stack_states;
    int miss = 0;
    for (int i = 0; i < n_ref; ++i) {
        int curr = arr_ref[i];

        int change_pos = -1;
        while (!primary.empty()) {
            int temp = primary.top();
            primary.pop();
            if(temp == curr) {
                change_pos = temp;
                break;
            }
            secondary.push(temp);
        }

        while (!secondary.empty()) {
            primary.push(secondary.top());
            secondary.pop();
        }

        if (change_pos != -1) {
            primary.push(change_pos);
        }
        else {
            if (primary.size() >= n_frame) {
                while (!primary.empty()) {
                    secondary.push(primary.top());
                    primary.pop();
                }
                secondary.pop();
                while (!secondary.empty()) {
                    primary.push(secondary.top());
                    secondary.pop();
                }
                primary.push(curr);
            }
            else {
                primary.push(curr);
            }
            ++miss;
        }
        stack_states.push_back(primary);
    }

    for (int k = 0; k < n_frame; ++k) {
        for (int i = 0; i < n_ref; ++i) {
            if (!stack_states[i].empty()) {
                cout << stack_states[i].top() << "  ";
                stack_states[i].pop();
            }
            else {
                cout << "   ";
            }
        }
        cout << endl;
    }
}

void enhanced_second_chance(int n_ref, int n_frame)
{
    struct page_info {
        int data;
        int recent;
        int modified;
        int priority;

        page_info(int data) {
            this->data = data;
            this->recent = 1;
            this->modified = 0;
            this->priority = 3;
        }
    };

    int miss = 0;
    list<page_info> pages;
    list<page_info>::iterator it, min_priority_it, find_it;
    vector<list<page_info> > states;
    for (int i = 0; i < n_ref; ++i) {

        int curr_data = arr_ref[i];
        page_info curr(curr_data);

        for (it = pages.begin(); it != pages.end(); ++it) {
            it->recent = 0;
            if (it->recent == 0 && it->modified == 0) {
                it->priority = 1;
            }
            if (it->recent == 0 && it->modified == 1) {
                it->priority = 2;
            }
            if (it->recent == 1 && it->modified == 0) {
                it->priority = 3;
            }
            if (it->recent == 1 && it->modified == 1) {
                it->priority = 4;
            }
        }
        find_it = find_if(pages.begin(), pages.end(), [&curr_data](const page_info &a){return a.data == curr_data;});
        if (find_it == pages.end()) {
            if (pages.size() >= n_frame) {
                int min_priority = 4;
                min_priority_it = pages.begin();
                for (it = pages.begin(); it != pages.end(); ++it) {
                    if(it->priority < min_priority) {
                        min_priority = it->priority;
                        min_priority_it = it;
                    }
                }
                pages.erase(min_priority_it);
            }
            pages.push_back(curr);
            ++miss;
        }
        else {
            curr.modified = 1;
            pages.erase(find_it);
            pages.push_back(curr);
        }

        states.push_back(pages);
    }

    for (int i = 0; i < n_frame; ++i) {
        for (int j = 0; j < states.size(); ++j) {
            if(!states[j].empty()) {
                cout << states[j].back().data << "  ";
                states[j].pop_back();
            }
            else {
                cout << "   ";
            }
        }
        cout << endl;
    }
    
}

int main()
{
    int n_pages;
    cout << "Number of pages: ";
    cin >> n_pages;

    cout << "Reference String: ";
    
    char in_ignore = ',';
    int input;
    int n_ref = 0;
    
    while (in_ignore == ',') {
        cin >> input;
        in_ignore = cin.get();
        arr_ref[n_ref] = input;
        ++n_ref;
    }

    int n_frame;
    cout << "Number of Memory Page Frame: ";
    cin >> n_frame;

    cout << endl << "Least Recently Used page replacement algorithm using stack:" << endl;
    lru_using_stack(n_ref, n_frame);

    cout << endl << "Enhanced second chance algorithm:" << endl;
    enhanced_second_chance(n_ref, n_frame);

}

/*

--------Sample Input--------
8
7,0,1,2,0,3,0,4,2,3,0,3,0,3,2,1,2,0,1,7,0,1
3

*/