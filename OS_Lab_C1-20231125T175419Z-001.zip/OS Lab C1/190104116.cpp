/*
Author: Kazi Toufique Elahi
ID: 190104116
Code: 1. Contiguous allocation (Sequential)
      2. Non Contiguous allocation
*/

#include <bits/stdc++.h>
using namespace std;

void contiguous_alloc()
{
    int n_blocks;
    cout << "Enter total number of blocks: ";
    cin >> n_blocks;

    string blocks[n_blocks];
    for (int i = 0; i < n_blocks; ++i) {
        blocks[i] = "";
    }

    int n_insert;
    cout << "Enter number of file creation query: ";
    cin >> n_insert;

    int head = 0;

    for (int i = 0; i < n_insert; ++i) {
        string f_name;
        cout << "Enter Filename: ";
        cin >> f_name;

        int f_size;
        cout << "Enter File-Size: ";
        cin >> f_size;

        int cnt_free = 0;
        bool found = false;
        for (int j = 0; j < n_blocks; ++j) {
            if (blocks[j].compare("") != 0) {
                cnt_free = 0;
            }
            else {
                if (cnt_free == 0) {
                    head = j;
                }
                ++cnt_free;
                if (cnt_free == f_size) {
                    found = true;
                    break;
                }
            }
        }

        if (!found) {
            cout << "File " << f_name << " cannot be created (not enough free blocks)" << endl << endl;
            continue;
        }

        for (int j = 0; j < f_size; ++j) {
            blocks[head++] = f_name;
        }
        cout << "File " << f_name << " created" << endl;
        cout << endl;
    }

    int n_search;
    cout << "Enter number of file seach query: ";
    cin >> n_search;

    for (int i = 0; i < n_search; ++i) {
        string f_name;
        cout << "Search Filename: ";
        cin >> f_name;

        vector<int> sequence;

        for (int j = 0; j < n_blocks; ++j) {
            if (blocks[j].compare(f_name) == 0) {
                sequence.push_back(j);
            }
        }
        
        int len = sequence.size();
        if (len > 0) {
            cout << "File Found in the blocks: ";
            for (int j = 0; j < len; ++j) {
                cout << sequence[j];
                if (j != len - 1) {
                    cout << ",";
                }
            }
        }
        else {
            cout << "File not Found.";
        }
        cout << endl << endl;
    }
}

void non_contiguous_alloc()
{
    int n_blocks;
    cout << "Enter total number of blocks: ";
    cin >> n_blocks;

    int avail = n_blocks;

    string blocks[n_blocks];
    for (int i = 0; i < n_blocks; ++i) {
        blocks[i] = "";
    }

    int n_insert;
    cout << "Enter number of file creation query: ";
    cin >> n_insert;

    for (int i = 0; i < n_insert; ++i) {
        string f_name;
        cout << "Enter Filename: ";
        cin >> f_name;

        int f_size;
        cout << "Enter File-Size: ";
        cin >> f_size;

        vector<int> sequence;

        for (int j = 0; j < n_blocks; ++j) {
            if (blocks[j].compare("") == 0) {
                sequence.push_back(j);
            }
            if (sequence.size() >= f_size) {
                break;
            }
        }

        if (sequence.size() < f_size) {
            cout << "File " << f_name << " cannot be created (not enough free blocks)" << endl << endl;
            continue;
        }
        else {
            for (int j = 0; j < sequence.size(); ++j) {
                blocks[sequence[j]] = f_name;
            }
        }
        cout << "File " << f_name << " created" << endl << endl;
    }

    int n_search;
    cout << "Enter number of file seach query: ";
    cin >> n_search;

    for (int i = 0; i < n_search; ++i) {
        string f_name;
        cout << "Search Filename: ";
        cin >> f_name;

        vector<int> sequence;

        for (int j = 0; j < n_blocks; ++j) {
            if (blocks[j].compare(f_name) == 0) {
                sequence.push_back(j);
            }
        }
        
        int len = sequence.size();
        if (len > 0) {
            cout << "File Found in the blocks: ";
            for (int j = 0; j < len; ++j) {
                cout << sequence[j];
                if (j != len - 1) {
                    cout << ",";
                }
            }
        }
        else {
            cout << "File not Found.";
        }
        cout << endl << endl;
    }
}


int main()
{
    
    cout << "-----------------------------------" << endl;
    cout << "Contiguous allocation (Sequential):" << endl;
    cout << "-----------------------------------" << endl;
    contiguous_alloc();
    
    cout << "--------------------------" << endl;
    cout << "Non Contiguous allocation:" << endl;
    cout << "--------------------------" << endl;
    non_contiguous_alloc();
    
}

/*

--------Sample Input--------
200
3
A
4
B
400
C
40
2
A
D

200
3
A
4
B
150
C
40
2
D
C

*/